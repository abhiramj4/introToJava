import java.util.*;
/**
 * Write a description of class TransporterRoom here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class TransporterRoom extends Room
{
    // instance variables - replace the example below with your own
    private int x;
    private ArrayList<Room> gRooms;
    private HashMap<String, Room> exits;
    /**
     * Constructor for objects of class TransporterRoom
     */
    public TransporterRoom(String description)
    {
        super(description);
        gRooms = new ArrayList<Room>();
    }
    
    /**
     * Choose a random room.
     *
     * @return The room we end up in upon leaving this one.
     */
    private Room findRandomRoom()
    {
        //randomly search the arraylist of rooms

        Random r = new Random();
        int index = r.nextInt((gRooms).size());
        Room randomRoom = gRooms.get(index);
        
        return randomRoom;
    }
    
    public void passedRooms(ArrayList<Room> rooms){
           
        for(Room r:rooms){
            gRooms.add(r);

        }
    }
    
    public Room getExit(String direction)
    {
        return findRandomRoom();
    }
}
